
// Einfacher Monatskalender (Mo-Su)
const monthYear = document.getElementById('monthYear');
const daysGrid = document.getElementById('days');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');

let today = new Date();
let viewDate = new Date(today.getFullYear(), today.getMonth(), 1);
let selectedDate = null;

function render() {
  daysGrid.innerHTML = '';
  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();

  // Kopfzeile
  monthYear.textContent = viewDate.toLocaleString('de-DE', { month: 'long', year: 'numeric' });

  // Erster Wochentag des Monats (in JS: 0=So,1=Mo,...). Wir wollen Mo=0..So=6
  const firstDay = new Date(year, month, 1).getDay();
  const shift = (firstDay + 6) % 7; // verschiebe So->6, Mo->0, etc.

  // Anzahl Tage im Monat und im vorherigen Monat
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const prevDays = new Date(year, month, 0).getDate();

  // Fülle Tage: vorheriger Monat (falls shift>0)
  for (let i = shift - 1; i >= 0; i--) {
    const d = prevDays - i;
    const el = createDayElement(new Date(year, month - 1, d), true);
    daysGrid.appendChild(el);
  }

  // Tage des aktuellen Monats
  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(year, month, d);
    const el = createDayElement(date, false);
    daysGrid.appendChild(el);
  }

  // Auffüllen mit Tagen des nächsten Monats bis vollständiges Raster (7*n)
  while (daysGrid.children.length % 7 !== 0) {
    const nextDay = daysGrid.children.length - (shift + daysInMonth) + 1;
    const date = new Date(year, month + 1, nextDay);
    const el = createDayElement(date, true);
    daysGrid.appendChild(el);
  }
}

function createDayElement(date, otherMonth) {
  const el = document.createElement('button');
  el.className = 'day' + (otherMonth ? ' other-month' : '');
  el.type = 'button';
  el.textContent = date.getDate();

  // Markiere heute
  if (sameDay(date, today)) el.classList.add('today');

  // Markiere ausgewählte
  if (selectedDate && sameDay(date, selectedDate)) el.classList.add('selected');

  el.addEventListener('click', () => {
    selectedDate = date;
    // wenn der Klick auf einen Tag eines anderen Monats war, wechsele Ansicht
    if (otherMonth) {
      viewDate = new Date(date.getFullYear(), date.getMonth(), 1);
    }
    render();
    // Aktion bei Auswahl: Beispiel-Event (replace mit eigener Logik)
    console.log('Gewählte Datum:', date.toISOString().slice(0,10));
  });

  return el;
}

function sameDay(a,b){
  return a && b && a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate();
}

prevBtn.addEventListener('click', () => {
  viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth() - 1, 1);
  render();
});
nextBtn.addEventListener('click', () => {
  viewDate = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 1);
  render();
});

// Initial
render();